<?php

namespace App\Http\Controllers\PDV;

use App\classes\CheckData;
use App\Http\Controllers\Controller;
use App\Models\caixa;
use App\Models\category_product;
use App\Models\operation_caixa_type_session;
use App\Models\operationCaixaType;
use App\Models\orderPos;
use App\Models\Password_Invoice_Cancel;
use App\Models\paymentMethod;
use App\Models\produtos;
use App\Models\session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use Inertia\Inertia;

class PointSaleController extends Controller
{
    public function index(caixa $caixa)
    {
        $data = $caixa->session()->where('user_id', Auth::user()->id)
            ->where('state', 'Aberto')
            ->orderBy('id', 'DESC')
            ->first();
        if (!$data) {
            return Redirect::route('pontodevenda');
        }

        return Inertia::render('PointSale/Pos', [
            'user' => Auth::user(),
            'data' => Auth::user()->company,
            'session' => $data
        ]);
    }

    public function getTypeOperation(operationCaixaType $operationCaixaType,$locale)
    {
        return $operationCaixaType::with(['operationTranslate'=>function($translate) use ($locale){
            $translate->where('local',$locale);
        }])->get();
    }

    public function addOperation(Request $request)
    {
        $checkPermission = new CheckData;
        if(!$checkPermission->checkPermission('POS','Spend')) return $this->RespondError(__('User without access'));
        $data = $request->data;
        $data['user_id'] = Auth::user()->id;
        $data['company_id'] = Auth::user()->company_id;
        if (operation_caixa_type_session::create($data)) {
            return $this->RespondSuccess(__('Operation completed successfully'));
        }
    }

    public function menuPos($locale)
    {
        $methods = paymentMethod::with(['methodTranslate'=>function($translate) use ($locale){
            $translate->where('local',$locale);
        }])->get();
        $category = category_product::all();
        return response()->json([
            'User' => Auth::user(),
            'methods' => $methods,
            'categories'=>$category
        ]);
    }

    public function PasswordCash(Request $request, session $session)
    {
        $session->load('caixa');
        if (Hash::check($request->password['password'], $session->caixa->password)) {
            return $this->RespondSuccess('connected');
        }
        return $this->RespondError(__('data incorrect.'));
    }

    public function getUsersAuthorized()
    {
        return Password_Invoice_Cancel::all();
    }

    public function CancelInvoice(Request $request, $user, orderPos $invoice, OrdersController $ordersController)
    {
        $checkPermission = new CheckData;
        if(!$checkPermission->checkPermission('POS','Cancel invoice')) return $this->RespondError(__('User without access'));
        $request->validate([
            'password' => "required"
        ]);

        if ($user == null || !is_numeric($user))
            return $this->RespondError("Seleciona um usuario valido");

        $user = Password_Invoice_Cancel::where('user_id', $user)->first();

        if (!Hash::check($request->password, $user->password))
            return $this->RespondError(__('data incorrect.'));
        $order = $invoice->with(['items' => function ($query) {
            $query->with(['product' => function ($product) {
                $product->withSum('stock', 'quantity');
            }]);
        }])->whereId($invoice->id)->first();

        $ordersController->CancelInvoice($invoice);
        $invoice->number = 0;
        $invoice->save();

        return $this->RespondSuccess('Pedido de anulação enviado com sucesso', $order);
    }
}
